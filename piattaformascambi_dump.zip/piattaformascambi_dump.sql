-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 08, 2024 alle 16:11
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `piattaformascambi`
--
CREATE DATABASE IF NOT EXISTS `piattaformascambi` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `piattaformascambi`;

-- --------------------------------------------------------

--
-- Struttura della tabella `annunci`
--

CREATE TABLE `annunci` (
  `ID` int(11) NOT NULL,
  `Titolo` varchar(50) NOT NULL,
  `Descrizione` varchar(300) DEFAULT NULL,
  `Categoria` varchar(25) NOT NULL,
  `Condizioni` varchar(50) NOT NULL,
  `Luogo` varchar(40) NOT NULL,
  `Data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Utente` varchar(30) NOT NULL,
  `Visibile` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `annunci`
--

INSERT INTO `annunci` (`ID`, `Titolo`, `Descrizione`, `Categoria`, `Condizioni`, `Luogo`, `Data`, `Utente`, `Visibile`) VALUES
(83, 'Libro Rage and Ruin', 'Scambio libro Rage and Ruin. Ottime condizioni.', 'Libri', 'Come Nuovo', 'Caserta', '2024-06-08 13:22:29', 'mariorossi', 0),
(84, 'FIFA 16 Playstation 4', 'Scambio vecchio gioco per la PS4. Usato ma funzionante.', 'Intrattenimento', 'Buone Condizioni', 'Caserta', '2024-06-08 11:30:52', 'mariorossi', 1),
(85, 'Quadro Natura', 'Scambio vecchio quadro per inutilizzo. Possibilmente cerco altri quadri.', 'Collezionismo', 'Come Nuovo', 'Caserta', '2024-06-08 11:41:21', 'mariorossi', 0),
(86, 'GTA 5', 'Scambio per inutilizzo gioco per la ps4. GTA5, in condizioni molto buone. Cerco altri giochi PS4.', 'Intrattenimento', 'Come Nuovo', 'Avellino', '2024-06-08 13:22:29', 'lucabianchi', 0),
(87, 'Libro di Harry Potter', 'Scambio libro di Harry Potter per regalo non utilizzato. Condizioni perfette', 'Libri', 'Come Nuovo', 'Salerno', '2024-06-08 11:35:56', 'lucabianchi', 1),
(88, 'Giacca uomo grigia', 'Cerco altri capi di abbigliamento', 'Abbigliamento', 'Come Nuovo', 'Avellino', '2024-06-08 11:37:38', 'lucabianchi', 1),
(89, 'Shadow and Bone Libro', '', 'Libri', 'Nuovo', 'Avellino', '2024-06-08 11:38:56', 'luciabianchi', 1),
(90, 'Scheda Microcontrollore ESP32', 'Scambio scheda programmabile ESP32', 'Elettronica', 'Come Nuovo', 'Avellino', '2024-06-08 11:41:21', 'luciabianchi', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `foto`
--

CREATE TABLE `foto` (
  `URL` varchar(150) NOT NULL,
  `Annuncio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `foto`
--

INSERT INTO `foto` (`URL`, `Annuncio`) VALUES
('Photos/rageandruin_2.jpg', 83),
('Photos/fifa16_1.jpg', 84),
('Photos/resonance.jpg', 85),
('Photos/gta5_1.png', 86),
('Photos/harrypotter.jpg', 87),
('Photos/giacca.JPG', 88),
('Photos/shadowandbone_1.jpg', 89),
('Photos/esp32.png', 90);

-- --------------------------------------------------------

--
-- Struttura della tabella `propostedichiusuratrattativa`
--

CREATE TABLE `propostedichiusuratrattativa` (
  `DataEmissioneProposta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `annuncio_richiesto` int(11) NOT NULL,
  `annuncio_proposto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `propostedichiusuratrattativa`
--

INSERT INTO `propostedichiusuratrattativa` (`DataEmissioneProposta`, `annuncio_richiesto`, `annuncio_proposto`) VALUES
('2024-06-08 13:19:03', 89, 87);

-- --------------------------------------------------------

--
-- Struttura della tabella `recensioni`
--

CREATE TABLE `recensioni` (
  `Testo` varchar(300) DEFAULT NULL,
  `Rating` smallint(6) NOT NULL,
  `utente_scrivente` varchar(30) NOT NULL,
  `utente_ricevente` varchar(30) NOT NULL,
  `annuncio_avvio_scambio` int(11) NOT NULL,
  `annuncio_completamento_scambio` int(11) DEFAULT NULL,
  `Data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `recensioni`
--

INSERT INTO `recensioni` (`Testo`, `Rating`, `utente_scrivente`, `utente_ricevente`, `annuncio_avvio_scambio`, `annuncio_completamento_scambio`, `Data`) VALUES
('Ho avuto un\'ottima esperienza', 5, 'luciabianchi', 'mariorossi', 85, 90, '2024-06-08 11:41:36'),
('', 5, 'mariorossi', 'lucabianchi', 83, 86, '2024-06-08 13:45:44'),
('Non ho avuto un\'ottima esperienza', 2, 'mariorossi', 'luciabianchi', 85, 90, '2024-06-08 11:42:19');

-- --------------------------------------------------------

--
-- Struttura della tabella `richiestetrattativa`
--

CREATE TABLE `richiestetrattativa` (
  `DataEmissioneRichiesta` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `offerente` varchar(30) NOT NULL,
  `annuncio_richiesto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `richiestetrattativa`
--

INSERT INTO `richiestetrattativa` (`DataEmissioneRichiesta`, `offerente`, `annuncio_richiesto`) VALUES
('2024-06-08 11:40:13', 'luciabianchi', 87),
('2024-06-08 11:40:15', 'luciabianchi', 88);

-- --------------------------------------------------------

--
-- Struttura della tabella `scambi`
--

CREATE TABLE `scambi` (
  `DataChiusuraScambio` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `annuncio_avvio` int(11) NOT NULL,
  `annuncio_completamento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `scambi`
--

INSERT INTO `scambi` (`DataChiusuraScambio`, `annuncio_avvio`, `annuncio_completamento`) VALUES
('2024-06-08 13:22:29', 83, 86),
('2024-06-08 11:41:21', 85, 90);

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `nome` varchar(30) NOT NULL,
  `cognome` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `hashedpassword` varchar(50) NOT NULL,
  `ValutazioneMedia` double DEFAULT NULL,
  `RecensioniRicevute` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`nome`, `cognome`, `email`, `username`, `hashedpassword`, `ValutazioneMedia`, `RecensioniRicevute`) VALUES
('Francesco', 'Blu', 'francescoblu@gmail.com', 'francescoblu', 'cdb06dd5511dccdc6c31a2bf26fcae0e', NULL, 0),
('Luca', 'Bianchi', 'lucabianchi@gmail.com', 'lucabianchi', '11d5f462a21356d7442ee1c7f874da19', 5, 1),
('Lucia', 'Bianchi', 'luciabianchi@gmail.com', 'luciabianchi', '595c18339f7a57f2fe7fa12cac7ed0f9', 2, 1),
('Mario', 'Rossi', 'mariorossi@gmail.com', 'mariorossi', '3bbcc24611248ab6fca038c1cae0c576', 5, 1);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `annunci`
--
ALTER TABLE `annunci`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Utente` (`Utente`);

--
-- Indici per le tabelle `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`URL`),
  ADD KEY `Annuncio` (`Annuncio`);

--
-- Indici per le tabelle `propostedichiusuratrattativa`
--
ALTER TABLE `propostedichiusuratrattativa`
  ADD PRIMARY KEY (`annuncio_richiesto`,`annuncio_proposto`),
  ADD KEY `annuncio_proposto` (`annuncio_proposto`);

--
-- Indici per le tabelle `recensioni`
--
ALTER TABLE `recensioni`
  ADD PRIMARY KEY (`utente_scrivente`,`annuncio_avvio_scambio`),
  ADD KEY `utente_ricevente` (`utente_ricevente`),
  ADD KEY `annuncio_avvio_scambio` (`annuncio_avvio_scambio`),
  ADD KEY `annuncio_completamento_scambio` (`annuncio_completamento_scambio`);

--
-- Indici per le tabelle `richiestetrattativa`
--
ALTER TABLE `richiestetrattativa`
  ADD PRIMARY KEY (`offerente`,`annuncio_richiesto`),
  ADD KEY `annuncio_richiesto` (`annuncio_richiesto`);

--
-- Indici per le tabelle `scambi`
--
ALTER TABLE `scambi`
  ADD PRIMARY KEY (`annuncio_avvio`),
  ADD KEY `annuncio_completamento` (`annuncio_completamento`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `annunci`
--
ALTER TABLE `annunci`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `annunci`
--
ALTER TABLE `annunci`
  ADD CONSTRAINT `annunci_ibfk_1` FOREIGN KEY (`Utente`) REFERENCES `utenti` (`username`) ON DELETE CASCADE;

--
-- Limiti per la tabella `foto`
--
ALTER TABLE `foto`
  ADD CONSTRAINT `foto_ibfk_1` FOREIGN KEY (`Annuncio`) REFERENCES `annunci` (`ID`) ON DELETE CASCADE;

--
-- Limiti per la tabella `propostedichiusuratrattativa`
--
ALTER TABLE `propostedichiusuratrattativa`
  ADD CONSTRAINT `propostedichiusuratrattativa_ibfk_1` FOREIGN KEY (`annuncio_richiesto`) REFERENCES `annunci` (`ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `propostedichiusuratrattativa_ibfk_2` FOREIGN KEY (`annuncio_proposto`) REFERENCES `annunci` (`ID`) ON DELETE CASCADE;

--
-- Limiti per la tabella `recensioni`
--
ALTER TABLE `recensioni`
  ADD CONSTRAINT `recensioni_ibfk_1` FOREIGN KEY (`utente_scrivente`) REFERENCES `utenti` (`username`),
  ADD CONSTRAINT `recensioni_ibfk_2` FOREIGN KEY (`utente_ricevente`) REFERENCES `utenti` (`username`),
  ADD CONSTRAINT `recensioni_ibfk_3` FOREIGN KEY (`annuncio_avvio_scambio`) REFERENCES `annunci` (`ID`),
  ADD CONSTRAINT `recensioni_ibfk_4` FOREIGN KEY (`annuncio_completamento_scambio`) REFERENCES `annunci` (`ID`);

--
-- Limiti per la tabella `richiestetrattativa`
--
ALTER TABLE `richiestetrattativa`
  ADD CONSTRAINT `richiestetrattativa_ibfk_1` FOREIGN KEY (`offerente`) REFERENCES `utenti` (`username`) ON DELETE CASCADE,
  ADD CONSTRAINT `richiestetrattativa_ibfk_2` FOREIGN KEY (`annuncio_richiesto`) REFERENCES `annunci` (`ID`) ON DELETE CASCADE;

--
-- Limiti per la tabella `scambi`
--
ALTER TABLE `scambi`
  ADD CONSTRAINT `scambi_ibfk_1` FOREIGN KEY (`annuncio_avvio`) REFERENCES `annunci` (`ID`),
  ADD CONSTRAINT `scambi_ibfk_2` FOREIGN KEY (`annuncio_completamento`) REFERENCES `annunci` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
